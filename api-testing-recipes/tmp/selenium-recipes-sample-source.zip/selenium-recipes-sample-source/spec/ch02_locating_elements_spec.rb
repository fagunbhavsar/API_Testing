load File.dirname(__FILE__) + '/../test_helper.rb'

describe "Selenium Recipes - Locating Elements" do
  include TestHelper

  before(:all) do
    @driver = $browser =  Selenium::WebDriver.for(browser_type)
  end

  before(:each) do
    driver.navigate.to(site_url + "/locators.html")
  end

  after(:all) do
    driver.quit unless debugging? || driver.nil?
  end

  it "By ID" do
    driver.find_element(:id, "submit_btn").click
  end

  it "By Name" do
    driver.find_element(:name, "comment").send_keys("Selenium Cool")
  end

  it "By Link Text" do
    driver.find_element(:link_text, "Cancel").click
  end

  it "By Partial Link Text" do
    # will click the "Cancel" link
    driver.find_element(:partial_link_text, "ance").click
  end
  
  it "By XPath" do    
    driver.find_element(:xpath, "//*[@id='div2']/input[@type='checkbox']").click
  end

  it "By Tag" do    
    expect(driver.find_element(:tag_name, "body").text).to include("Selenium Locators")
  end
  
  it "By Class" do
    driver.find_element(:class, "btn-primary").click
    sleep 1
    driver.find_element(:class_name, "btn").click
    
    # the below will return error "Compound class names not permitted"
    # driver.find_element(:class, "btn btn-deault btn-primary").click    
  end
  
  it "By CSS Selector" do
    driver.find_element(:css, "#div2 > input[type='checkbox']").click    
  end
  
  it "Chain find_element to find child elements" do
    driver.find_element(:id, "div2").find_element(:name, "same").click
  end
  
  it "Find multiple elements" do
    checkbox_elems = driver.find_elements(:xpath, "//div[@id='container']//input[@type='checkbox']")
    debug(checkbox_elems.count) # => 2
    checkbox_elems[1].click
  end
  
end
