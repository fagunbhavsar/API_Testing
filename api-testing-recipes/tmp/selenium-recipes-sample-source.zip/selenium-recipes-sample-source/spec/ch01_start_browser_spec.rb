require 'selenium-webdriver'

describe "Selenium Recipes - Start different browers" do
 
  it "Start Chrome" do
    driver = Selenium::WebDriver.for(:chrome)
    driver.navigate.to("http://travel.agileway.net")
    sleep 1
    driver.quit
  end

  it "Start FireFox" do
    driver = Selenium::WebDriver.for(:firefox)
    driver.navigate.to("http://travel.agileway.net")
    expect(driver.title).to eq("Agile Travel")
    sleep 1
    driver.quit
  end

  it "Start IE" do
    if RUBY_PLATFORM =~ /mingw/
      driver = Selenium::WebDriver.for(:ie)
      driver.get("http://travel.agileway.net")
      sleep 1
      expect(driver.page_source).to include("User Name")
      driver.quit
    end
  end

 # need install MicrosoftWebDriver 
  it "Start Edge" do
     if RUBY_PLATFORM =~ /mingw/ # check platform
       driver = Selenium::WebDriver.for(:edge)
       driver.navigate.to("http://testwisely.com/demo")
       sleep 1
       driver.quit
     end
  end
  
  # need install SafariDriver 
  it "Start safari" do
     if RUBY_PLATFORM =~ /darwin/ # check platform
       driver = Selenium::WebDriver.for(:safari)
       driver.navigate.to("http://testwisely.com/demo")
       sleep 1
       driver.quit
     end
  end
   
end
