load File.dirname(__FILE__) + '/../test_helper.rb'

describe "Selenium Recipes - Links" do
  include TestHelper

  before(:all) do
    @driver = $browser =  Selenium::WebDriver.for(browser_type)
  end

  before(:each) do
    driver.navigate.to(site_url + "/link.html")
  end

  after(:all) do
    driver.quit unless debugging? || driver.nil?
  end

  it "Click link by text" do
    driver.find_element(:link_text, "Recommend Selenium").click
  end

  it "Click link by ID" do
    driver.find_element(:id, "recommend_selenium_link").click
  end

  it "Click link by partial text" do
    driver.find_element(:partial_link_text, "Recommend Selenium").click
  end

  it "Click link by xpath" do
    driver.find_element(:xpath, "//p/a[text()='Recommend Selenium']").click()
    driver.navigate.to(site_url)
  end


  it "Click link by xpath using function" do
    # Click the link (two on the same page), click the second one by narrowing down with parent div
    # using XPath contains() functions
    driver.find_element(:xpath, '//div[contains(text(), "Second")]/a[text()="Click here"]').click()
    # copied xpath //*[@id="container"]/div[3]/div[2]/a, not very good
  end
  # driver.find_element(:link_text, /watir/i).click
  
  it "Click second link with exact text using array index" do
    expect(driver.find_elements(:link_text, "Same link").size).to eq(2)
    driver.find_elements(:link_text => "Same link")[1].click # second link
    expect(driver.page_source).to include("second link page")
  end
  
  it "Click second link with exact text using CSS locator" do
    driver.find_element(:css, "p  > a:nth-child(3)").click
    expect(driver.page_source).to include("second link page")
  end

  it "Test links openning another window or tab - remember URL" do
    current_url = driver.current_url
    new_window_url = driver.find_element(:link_text, "Open new window")["href"]
    driver.navigate.to(new_window_url)
    # ... testing on new site
    driver.find_element(:name, "name").send_keys "sometext"
    driver.navigate.to(current_url) # back
  end


 it "Test links openning another window or tab" do
    current_url = driver.current_url
    driver.find_element(:link_text, "Open new window").click
    driver.switch_to.window(driver.window_handles[-1])
    driver.find_element(:name, "name").send_keys "sometext"
    driver.close
    driver.switch_to.window(driver.window_handles[0])
    driver.find_element(:link_text, "Recommend Selenium").click
  end


  # Retrieve link other attributes
  #

  it "Retrieve common link details" do
    
    expect(driver.find_element(:link_text, "Recommend Selenium")["href"]).to include("/site/index.html")
    expect(driver.find_element(:link_text, "Recommend Selenium")["id"]).to eq("recommend_selenium_link")
    expect(driver.find_element(:id, "recommend_selenium_link").text).to eq("Recommend Selenium")
    expect(driver.find_element(:id, "recommend_selenium_link").tag_name).to eq("a")
    
    # older RSpec should-base syntax
    driver.find_element(:link_text, "Recommend Selenium")["href"].should include("/site/index.html")
    driver.find_element(:link_text, "Recommend Selenium")["id"].should == "recommend_selenium_link"
    driver.find_element(:id, "recommend_selenium_link").text.should == "Recommend Selenium"
    driver.find_element(:id, "recommend_selenium_link").tag_name.should == "a"
  end

  it "Retrieve advanced link attributes" do
    expect(driver.find_element(:id, "recommend_selenium_link")["style"]).to eq("font-size: 14px;")
    # Please note using attribute_value("style") won't work
    expect(driver.find_element(:id, "recommend_selenium_link").attribute("data-id")).to eq("123")
  end


  # Verify links
  #

  it "Verify link present" do
    
    # if using assert
    # assert driver.find_element(:link_text, "Recommend Selenium").displayed?
    # assert !driver.find_element(:id, "recommend_selenium_link").displayed?
  
    # RSpec expect-based syntax
    expect(driver.find_element(:link_text, "Recommend Selenium").displayed?).to be_truthy
    expect(driver.find_element(:link_text, "Recommend Selenium").displayed?).to be true
    expect(driver.find_element(:link_text, "Recommend Selenium").displayed?).not_to be be_truthy
  
    
    # RSpec should-based syntax
    driver.find_element(:link_text, "Recommend Selenium").displayed?.should be_truthy
    driver.find_element(:id, "recommend_selenium_link").displayed?.should be_truthy
  end

  it "Verify link displayed or hidden" do
    expect(driver.find_element(:link_text, "Recommend Selenium").displayed?).to be_truthy
    expect(driver.find_element(:id, "recommend_selenium_link").displayed?).to be_truthy

    driver.find_element(:link_text, "Hide").click
    sleep 1
    begin
      # different from Watir, selenium returns element not found
      expect(driver.find_element(:link_text, "Recommend Selenium").displayed?).to be_falsey
    rescue Selenium::WebDriver::Error::NoSuchElementError => e
      puts "[Selenium] The hidden link cannot be found"
    end

    driver.find_element(:link_text, "Show").click
    sleep 1
    expect(driver.find_element(:link_text, "Recommend Selenium").displayed?).to be_truthy
  end

=begin

  ## WISH Selenium supports syntax like below 
  
  it "Click link chained by class and text" do
    driver.find_elements(:link_text => "Same link").size.should == 2
    a = driver.find_elements(:class => 'small', :link_text => "Same link")
    debug a.size
    a.first.click
    # .click
    # driver.find_elements(:class, 'small').find_element(:link_text, "Same link").click
    driver.page_source.should include("partial link page")
  end

  # index

  it "Click second link with exact text by narrowing down with :class" do
    driver.find_elements(:link_text, "Same link").size.should == 2
    driver.find_element(:link_text => "Same link").find_element(:class, "small").click
    driver.page_source.should include("second link page")
  end

=end

end
