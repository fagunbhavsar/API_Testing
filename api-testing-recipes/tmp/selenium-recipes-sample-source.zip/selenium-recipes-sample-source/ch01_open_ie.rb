require 'selenium-webdriver'
driver = Selenium::WebDriver.for(:ie)
driver.navigate.to("http://testwisely.com/demo")