require 'selenium-webdriver'
driver = Selenium::WebDriver.for(:chrome)
driver.navigate.to("http://testwisely.com/demo")
sleep 1 # wait 1 second
driver.quit