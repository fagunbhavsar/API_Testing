load File.dirname(__FILE__) + '/../test_helper.rb'
load File.dirname(__FILE__) + '/../mail_catcher_helper.rb'

describe "Email with mail catcher" do

  include TestHelper
  include MailCatcherHelper

  before(:all) do    
  end

  after(:all) do
  end

  
 
end
